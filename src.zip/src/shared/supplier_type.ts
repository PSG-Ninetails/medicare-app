export interface Supplier {
    id: number;
    name: string;
    store_name: string;
    image: string;
    description: string;
}