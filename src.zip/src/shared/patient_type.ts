import { Prescription } from './prescription_type';
import { VisitedDoc } from './visited';
import { PApt } from './papt';
export interface Patient {
    $key: string;
    username: string;
    password: string;
    name: string;
    contact: string;
    prescription: Prescription[];
    recentlyvisited: VisitedDoc[];
    apt: PApt[];
}