export interface Prescription {
    id: string;     //combination of 'doctor' + 'patient' id       //currently doc id is assigned.
    dname: string;
    dtype: string;
    area: string;
    prb: string;
    aid: string;
}