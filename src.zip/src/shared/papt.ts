export interface PApt {
    did: string;
    dname: string;
    dtype: string;
    area: string;
    date: string;
}