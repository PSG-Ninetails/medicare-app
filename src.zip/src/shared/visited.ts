export interface VisitedDoc {
    did: string;
    dtype: string;
    dname: string;
    area: string;
}