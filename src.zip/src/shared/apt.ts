export interface DApt {
    pid: string;
    pname: string;
    contact: string;
}