export interface Problem {
    patient_id: string;
    patient_name: string;
    patient_problem: string;
}