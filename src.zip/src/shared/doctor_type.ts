import { Problem } from './problem';
import { DApt } from './apt';

export interface Doctor {
    $key: string;
    username: string;
    password: string;
    dtype: string;
    area: string;
    name: string;
    prb: Problem[];
    apt: DApt[];
    available: Boolean;
}