import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { baseURL } from '../shared/baseurl';
//import 'rxjs/add/operator/do';
//import 'rxjs/add/operator/map';
//import 'rxjs/add/operator/catch';

import { Observable } from 'rxjs';
import { Doctor } from '../shared/doctor_type';

@Injectable({
    providedIn: 'root'
})
export class DoctorService { 

    DoctorListRef: AngularFireList<any>;
    bookingRef: AngularFireObject<any>;

constructor(private http: HttpClient, private db: AngularFireDatabase) { }

    getDoctors(){
    this.DoctorListRef = this.db.list('/doctors');
    return this.DoctorListRef;
    }

    getDoctor(doc: string) {
        this.bookingRef = this.db.object('/doctors/' + doc);
        return this.bookingRef;
    }

    updateDoctors(doc: Doctor, id: string) {
        //console.log(doc);
        //this.http.put(baseURL + 'doctors/' + doc.id, JSON.stringify(doc), this.httpOptions).subscribe(res => console.log(res));
        //console.log(baseURL + 'doctors/' + doc.id);
        console.log(id);
        doc.$key = id;
        this.bookingRef = this.db.object('/doctors/' + doc.$key);
        this.bookingRef.update({
            username: doc.username,
            password: doc.password,
            dtype: doc.dtype,
            area: doc.area,
            name: doc.name,
            prb: doc.prb,
            apt: doc.apt,
            available: doc.available
        });
    }

    pushDoctors(doc: Doctor) {
        console.log(doc);
        //this.http.post(baseURL + 'doctors', doc).subscribe(res => console.log(res));
        this.DoctorListRef = this.db.list('/doctors');
        this.DoctorListRef.push({
            username: doc.username,
            password: doc.password,
            dtype: doc.dtype,
            area: doc.area,
            name: doc.name,
            prb: doc.prb,
            apt:doc.apt,
            available: doc.available
        });

    }
}
