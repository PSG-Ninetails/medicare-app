import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { baseURL } from '../shared/baseurl';

import { Observable } from 'rxjs';
import { Patient } from '../shared/patient_type';
import * as firebase from 'firebase';


@Injectable({
  providedIn: 'root'
})
export class PatientService {

    PatientListRef: AngularFireList<any>;
    bookingRef: AngularFireObject<any>;

    constructor(private http: HttpClient, private db: AngularFireDatabase) { }

   

    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    }

    getPatients() {            //: Observable<Patient[]> {
        //return this.http.get<Patient[]>(baseURL + 'patients');
        this.PatientListRef = this.db.list('/patients');
        return this.PatientListRef;
    }

    getPatient(pat: string) {
        this.bookingRef = this.db.object('/patients/' + pat);
        return this.bookingRef;
    }

    updatePatients(pat: Patient, id: string) {
        //console.log(doc);
        //this.http.put(baseURL + 'patients/' + pat.id, JSON.stringify(pat), this.httpOptions).subscribe(res => console.log(res));
        //console.log(baseURL + 'doctors/' + doc.id);
        console.log(id);
        pat.$key = id;
        this.bookingRef = this.db.object('/patients/' + pat.$key);
        this.bookingRef.update({
            username: pat.username,
            password: pat.password,
            name: pat.name,
            contact: pat.contact,
            prescription: pat.prescription,
            recentlyvisited: pat.recentlyvisited,
            apt: pat.apt
        });
    }

    pushPatients(pat: Patient) {
        //this.http.post(baseURL + 'patients', pat).subscribe(res => console.log(res));
        this.PatientListRef = this.db.list('/patients');
        this.PatientListRef.push({
            username: pat.username,
            password: pat.password,
            name: pat.name,
            contact: pat.contact,
            prescription: pat.prescription,
            recentlyvisited: pat.recentlyvisited,
            apt: pat.apt
        });

        //firebase.database().ref('patients/').push(pat);
    }
}
