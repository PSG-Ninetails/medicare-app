export const environment = {
    production: true,
    firebaseConfig : {
        apiKey: "AIzaSyB0FfLflNDKyMlabLah5sNe0ssNGtwf4tQ",
        authDomain: "ionicmeddb.firebaseapp.com",
        databaseURL: "https://ionicmeddb.firebaseio.com",
        projectId: "ionicmeddb",
        storageBucket: "ionicmeddb.appspot.com",
        messagingSenderId: "818260544264",
        appId: "1:818260544264:web:06561ddec7675e2731babd",
        measurementId: "G-K6DPCQW363"
    }
};
