import { Component, OnInit } from '@angular/core';
//import { User_Type } from '../../shared/user_type';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router, NavigationExtras } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Doctor } from '../../shared/doctor_type';
import { DoctorService } from '../../providers/doctor-service.service';
import { Patient } from '../../shared/patient_type';
import { PatientService } from '../../providers/patient-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

    loginForm: FormGroup;
    
    doctors: Doctor[];
    loggedDoctor: Doctor;

    patients: Patient[];
    loggedPatient: Patient;

    constructor(private formBuilder: FormBuilder, private router: Router, public toastController: ToastController,
        public doctorservice: DoctorService, public patientservice: PatientService)
    {
        this.loginForm = this.formBuilder.group({
            Username: [''],
            Password: [''],
            Category: ['']
        });

    }

    ngOnInit() {
        this.doctorservice.getDoctors().snapshotChanges().subscribe(res => {
            this.doctors = [];
            res.forEach(item => {
                let a = item.payload.toJSON();
                a['$key'] = item.key;
                //console.log(a['$key']);
                //console.log(a);
                this.doctors.push(a as Doctor);
            })
        });

        this.patientservice.getPatients().snapshotChanges().subscribe(res => {
            this.patients = [];
            res.forEach(item => {
                let a = item.payload.toJSON();
                a['$key'] = item.key;
                this.patients.push(a as Patient);
            })
        });
    }

    isPassword = true;
    Icon = true;                                               //Property Binding...dynamic icon and type of Password
    showPassword() {
        this.isPassword = !(this.isPassword);
        this.Icon = !(this.Icon);
    }

    onSubmit() {
        //console.log(this.doctors);
        var cnt = 0;
        if (this.loginForm.get('Category').value == 'doctor') {
            for (var d of this.doctors) {
                if (d.username == this.loginForm.get('Username').value && d.password == this.loginForm.get('Password').value) {
                    cnt = 1;
                    this.loggedDoctor = d;
                    
                    this.presentToast1();
                    let navigationExtras: NavigationExtras = {
                        state: {
                            doc: this.loggedDoctor
                        }
                    };
                    this.router.navigateByUrl('/doctor', navigationExtras);
                    break;
                }
            }
            if (cnt == 0)
                this.presentToast2();
        }
        else {
            if (this.loginForm.get('Category').value == 'patient') {
                for (var p of this.patients) {
                    if (p.username == this.loginForm.get('Username').value && p.password == this.loginForm.get('Password').value) {
                        cnt = 1;
                        this.loggedPatient = p;
                        this.presentToast1();
                        console.log(this.loggedPatient)
                        let navigationExtras: NavigationExtras = {
                            state: {
                                pat: this.loggedPatient
                            }
                        };
                        this.router.navigateByUrl('/patient', navigationExtras);
                        break;
                    }
                }
                if (cnt == 0)
                    this.presentToast2();
            }
        }


        //console.log(this.loggedDoctor.$key);      
    }

    
    async presentToast1() {
        const toast = await this.toastController.create({
            message: 'Login Successfull.',
            position: 'top',
            color: 'primary',
            duration: 2000
        });
        toast.present();
    }
    
    async presentToast2() {
        const toast = await this.toastController.create({
            position: 'top',
            color: 'danger',
            message: 'Wrong Username or Password',
            duration: 2000
        });
        toast.present();
    }
}
