import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Doctor } from '../../shared/doctor_type';
import { ModalController } from '@ionic/angular';
import { DoctormodalPage } from '../doctormodal/doctormodal.page';
//import { Prescription } from '../../shared/prescription_type';
import { PnotificationsPage } from '../pnotifications/pnotifications.page';
import { PataptPage } from '../patapt/patapt.page';
import { ToastController } from '@ionic/angular';
import { DoctorService } from '../../providers/doctor-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Patient } from '../../shared/patient_type';
import { VisitedPage } from '../visited/visited.page';
import { VisitedDoc } from '../../shared/visited';
import { PatientService } from '../../providers/patient-service.service';
//import { SocialSharing } from '@ionic-native/social-sharing/ngx';


@Component({
  selector: 'app-patient',
  templateUrl: './patient.page.html',
  styleUrls: ['./patient.page.scss'],
})
export class PatientPage implements OnInit {

    filterForm: FormGroup;
    specialists: any = [
        { label: 'Allergists', value: 'Allergists' }, { label: 'Cardiologists', value: 'Cardiologists' }
    ];

    locations: any = [
        { label: 'Sangavi', value: 'Sangavi' }, { label: 'Aundh', value: 'Aundh' }, { label: 'Shivajinagar', value: 'Shivajinagar' }
    ];


    doctors: Doctor[];
    pat_log: Patient;
    patient: Patient = { $key: '', username: '', password: '', name: '', contact: '', prescription: [], recentlyvisited: [], apt: [] };
    pNotiBadge: number = 0;
    recentBadge: number = 0;
    paptBadge: number = 0;
    selectedDoctors: Doctor[] = [];
    visiteddoc: VisitedDoc = { did:'', dname: '', dtype: '', area: '' };

    checkPres: Boolean;

    constructor(private formBuilder: FormBuilder, public modalController: ModalController,
        public modalController1: ModalController, public toastController: ToastController,
        public doctorservice: DoctorService, private route: ActivatedRoute,
        private router: Router, public modalController2: ModalController, public patientservice: PatientService,
        public modalController3: ModalController)
    {
        this.filterForm = this.formBuilder.group({
            Specialist: [''],
            Location: ['']
        });
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.pat_log = this.router.getCurrentNavigation().extras.state.pat;
            }
            console.log(this.pat_log); //always print inside paranthesis else undefined
            
        });
        
    }

    setBadgeandRecent() {
        this.pNotiBadge = this.patient.prescription.length;
        this.recentBadge = this.patient.recentlyvisited.length;
        this.paptBadge = this.patient.apt.length;
    }

    openPres() {
        if (this.patient.prescription.length != 0) {
            this.checkPres = true;
        }
        else
            this.checkPres = false;
    }

    ngOnInit() {
        this.patientservice.getPatient(this.pat_log.$key).valueChanges().subscribe(res => {   //fetchig received doctor from db to get updated one
            this.patient = res;
            console.log(this.patient);                  //this.patient does not contain key
            this.setBadgeandRecent();
        });

        

        //this.doctorservice.getDoctors().subscribe(doctors => this.doctors = doctors);
        this.doctorservice.getDoctors().snapshotChanges().subscribe(res => {
            this.doctors = [];
            res.forEach(item => {
                let a = item.payload.toJSON();
                a['$key'] = item.key;
                this.doctors.push(a as Doctor);
            })
        });
    }

    async presentModal(sd: Doctor) {
        this.visiteddoc.area = sd.area;
        this.visiteddoc.dname = sd.name;
        this.visiteddoc.dtype = sd.dtype;
        this.visiteddoc.did = sd.$key;
        var dummy = 0;
        for (var val of this.patient.recentlyvisited) {
            if (sd.$key == val.did) {
                dummy = 1;
                break;
            }
        }
        if (dummy == 0) {
            
            this.patient.recentlyvisited.push(this.visiteddoc);
            if (this.patient.recentlyvisited.length > 5) {
                this.patient.recentlyvisited.splice(1, 1);
            }
        }
        //console.log(this.patient.$key);    //no key 
        this.patientservice.updatePatients(this.patient, this.pat_log.$key);
         const modal = await this.modalController.create({
            component: DoctormodalPage,
            componentProps: {
                ss: sd,
                pat1_key: this.pat_log.$key
            }
            //cssClass: 'my-custom-class'
        });
        return await modal.present();
    }

    onSubmit() {
        this.selectedDoctors.splice(0, this.selectedDoctors.length);
        for (var val of this.doctors) {
            if (this.filterForm.get('Specialist').value == val['dtype'] && this.filterForm.get('Location').value == val['area'] && this.selectedDoctors.indexOf(val)===-1) {
                this.selectedDoctors.push(val);
            }
        }

    }

    presentPopover() {}

    async aptModal() {
        const modal3 = await this.modalController3.create({
            component: PataptPage,
            componentProps: {
                aptm: this.patient.apt
            }
            //cssClass: 'my-custom-class'
        });
        return await modal3.present();
    }
    
    async notificationModal() {
        this.openPres();
        if (this.checkPres) {

            const modal1 = await this.modalController1.create({
                component: PnotificationsPage,
                componentProps: {
                    noti: this.patient.prescription
                }
                //cssClass: 'my-custom-class'
            });
            return await modal1.present();
        }
        else {
            this.presentToast();
        }
    }

    async visitedModal() {

        //if (this.patient.recentlyvisited.length!=0) {
        console.log(this.patient.recentlyvisited);
            const modal2 = await this.modalController2.create({
                component: VisitedPage,
                componentProps: {
                    recent: this.patient
                    

                }
                //cssClass: 'my-custom-class'
            });
            return await modal2.present();
        //}
        //else {
          //  this.presentToast();
      //  }
    }

    async presentToast() {
        const toast = await this.toastController.create({
            position: 'bottom',
            color: 'danger',
            message: 'No Prescriptions to open.',
            duration: 2000
        });
        toast.present();
    }

    

}
