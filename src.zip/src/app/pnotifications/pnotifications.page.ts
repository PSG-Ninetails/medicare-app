import { Component, OnInit ,Input} from '@angular/core';
import { Prescription } from '../../shared/prescription_type';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-pnotifications',
  templateUrl: './pnotifications.page.html',
  styleUrls: ['./pnotifications.page.scss'],
})
export class PnotificationsPage implements OnInit {

    @Input() noti: Prescription[];

    constructor(private modalCtrl: ModalController) {

    }

  ngOnInit() {
  }

    dismiss() {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalCtrl.dismiss({
            'dismissed': true
        });
    }
}
