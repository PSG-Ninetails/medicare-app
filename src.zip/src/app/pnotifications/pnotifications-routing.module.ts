import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PnotificationsPage } from './pnotifications.page';

const routes: Routes = [
  {
    path: '',
    component: PnotificationsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PnotificationsPageRoutingModule {}
