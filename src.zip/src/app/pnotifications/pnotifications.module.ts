import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PnotificationsPageRoutingModule } from './pnotifications-routing.module';

import { PnotificationsPage } from './pnotifications.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PnotificationsPageRoutingModule
  ],
  declarations: [PnotificationsPage]
})
export class PnotificationsPageModule {}
