import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PnotificationsPage } from './pnotifications.page';

describe('PnotificationsPage', () => {
  let component: PnotificationsPage;
  let fixture: ComponentFixture<PnotificationsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PnotificationsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PnotificationsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
