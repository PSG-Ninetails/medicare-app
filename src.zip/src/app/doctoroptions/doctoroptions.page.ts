import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
//import { NavParams } from '@ionic/angular';
import { DoctorService } from '../../providers/doctor-service.service';
import { Doctor } from '../../shared/doctor_type';
import { Problem } from '../../shared/problem';
import { PatientService } from '../../providers/patient-service.service';
import { Patient } from '../../shared/patient_type';
import { Prescription } from '../../shared/prescription_type';
import { ToastController } from '@ionic/angular';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-doctoroptions',
  templateUrl: './doctoroptions.page.html',
  styleUrls: ['./doctoroptions.page.scss'],
})
export class DoctoroptionsPage implements OnInit {

    ishidden: Boolean; //reply and send button control
    doo: string; //currently logged doctor
    doo_fetched: Doctor = { $key: '', username: '', password: '', dtype: '', area: '', name: '', prb: [], apt: [], available: false };
    //initialize to avoid undefined error ,in *ngFor (HTML). 

    aid: string="";  //used as ngModel in ion-input to extract aid
    patients: Patient[];
    pat_fetch: Patient = { $key: '', username: '', password: '', name: '', contact: '', prescription: [], recentlyvisited: [], apt: [] };
    aidForm: FormGroup;
    selectedPatient: Problem = { patient_id: '', patient_name: '', patient_problem:'' };
    pres: Prescription = { id: '', aid: '', dtype: '', area: '', dname: '', prb:'' };    //initialize to avoid undefined error.

    constructor(private formBuilder: FormBuilder,private router: Router, private doctorservice: DoctorService, private route: ActivatedRoute,
        public patientservice: PatientService, public toastController: ToastController) {
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.doo = this.router.getCurrentNavigation().extras.state.doc1_key;
            }
            console.log(this.doo); //always print inside paranthesis else undefined
        });



        this.aidForm = this.formBuilder.group({
            Aid: ['']
        });
    }

    ngOnInit() {
        this.ishidden = true;

        this.doctorservice.getDoctor(this.doo).valueChanges().subscribe(res => {   //fetchig received doctor from db to get updated one
            this.doo_fetched = res;
            console.log(this.doo_fetched);    
        });

        //console.log(this.doo_fetched.prb);   //when printed on line 52 i.e inside subscribe not empty

        let bookingRes = this.patientservice.getPatients();
        bookingRes.snapshotChanges().subscribe(res => {
            this.patients = [];
            res.forEach(item => {
                let a = item.payload.toJSON();
                a['$key'] = item.key;
                this.patients.push(a as Patient);
            })
        })
    }


    back() {
        this.router.navigateByUrl('doctor');
    }

    openreply(p: Problem) {
        this.ishidden = false;
        this.selectedPatient = p;
        this.patientservice.getPatient(this.selectedPatient.patient_id).valueChanges().subscribe(res => {
            this.pat_fetch = res;
        });
    }

    sendtopatient() {
        this.pres.aid = this.aidForm.get('Aid').value;
        this.pres.id = this.doo; //currently doctor id is assigned to prescription id.....change it to get prescriptions uniquely.
        this.pres.dtype = this.doo_fetched.dtype;
        this.pres.area = this.doo_fetched.area;
        this.pres.dname = this.doo_fetched.name;
        this.pres.prb = this.selectedPatient.patient_problem;
        console.log(this.pres);
        this.pat_fetch.prescription.push(this.pres);
        this.patientservice.updatePatients(this.pat_fetch, this.selectedPatient.patient_id);
        this.presentToast1();
        this.ishidden = true;
    }

    async presentToast1() {
        const toast = await this.toastController.create({
            message: 'Prescription Sent to Patient Successfully.',
            position: 'middle',
            color: 'primary',
            duration: 2000
        });
        toast.present();
    }

}
