import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DoctoroptionsPage } from './doctoroptions.page';

describe('DoctoroptionsPage', () => {
  let component: DoctoroptionsPage;
  let fixture: ComponentFixture<DoctoroptionsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DoctoroptionsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DoctoroptionsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
