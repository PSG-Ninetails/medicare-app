import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DoctoroptionsPage } from './doctoroptions.page';

const routes: Routes = [
  {
    path: '',
    component: DoctoroptionsPage
    },
    {
        path: 'doctor',
        loadChildren: () => import('../doctor/doctor.module').then(m => m.DoctorPageModule)
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DoctoroptionsPageRoutingModule {}
