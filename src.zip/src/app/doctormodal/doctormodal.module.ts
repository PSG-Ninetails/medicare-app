import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DoctormodalPageRoutingModule } from './doctormodal-routing.module';

import { DoctormodalPage } from './doctormodal.page';

@NgModule({
  imports: [
        CommonModule,
        BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    DoctormodalPageRoutingModule
  ],
  declarations: [DoctormodalPage]
})
export class DoctormodalPageModule {}
