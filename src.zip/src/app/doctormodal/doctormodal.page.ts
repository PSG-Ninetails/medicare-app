import { Component, OnInit, Input,ViewChild} from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Doctor } from '../../shared/doctor_type';
import { FormBuilder, FormGroup} from '@angular/forms';
import { ToastController } from '@ionic/angular';
import { Problem } from '../../shared/problem';
import { DoctorService } from '../../providers/doctor-service.service';
import { PatientService } from '../../providers/patient-service.service';
import { Patient } from '../../shared/patient_type';
import { DApt } from '../../shared/apt';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-doctormodal',
  templateUrl: './doctormodal.page.html',
  styleUrls: ['./doctormodal.page.scss'],
})
export class DoctormodalPage implements OnInit {

    @Input() ss: Doctor;
    @Input() pat1_key: string;
    patient: Patient;
    doctor: Doctor={ $key: '', username: '', password: '', dtype: '', area: '', name: '', prb: [], apt: [], available: false };
    aptm: DApt = { pid: '', pname: '', contact:'' };
    
    ishidden: Boolean;
    openform: Boolean;
    aptForm: FormGroup;
    prbtosend: Problem = { patient_id: '', patient_name: '', patient_problem: '' };  //to send to doctor....{....} to avoid undefined error

    constructor(private modalCtrl: ModalController, private formbuilder: FormBuilder,
        public toastController: ToastController, public doctorservice: DoctorService,
        public toastController1: ToastController, public patientservice: PatientService, private socialSharing: SocialSharing,
    public toastController2: ToastController) {
        this.aptForm = this.formbuilder.group({
            myOmy: ['']
        });
        this.openform = false;
    }

    //flg1: Boolean=false;
    isavailable: Boolean=false;
    docStatus: string;
    ngOnInit() {
        console.log(this.ss.$key);

        this.patientservice.getPatient(this.pat1_key).valueChanges().subscribe(res => {   //fetchig received doctor from db to get updated one
            this.patient = res;
            //console.log(this.patient);
        });
        this.doctorservice.getDoctor(this.ss.$key).valueChanges().subscribe(res => {   //fetchig received doctor from db to get updated one
            this.doctor = res;
            console.log(this.doctor);
            //this.flg1 = this.doctor.available;
            //console.log(this.flg1);
            this.segmentChange(this.doctor.available);
        });

        //console.log(this.doctor.available);
        //console.log(this.flg1);

        
    }

    segmentChange(flg1: Boolean) {
        if (flg1 == true) {
            this.isavailable = true;
            this.docStatus = 'Available';
        }
        else {
            this.isavailable = false;
            this.docStatus = 'Not-available';
        }
    }

    dismiss() {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalCtrl.dismiss({
            'dismissed': true
        });
    }

    consult() {
        this.openform = true;  //to open form on button click
    }


    bookApt() {
        var cnt = 0;
        var splitted = [];
        var currentDatesplit = [];
        var aptFLAG = 0;
        
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();

        var today1 = dd + '/' + mm + '/' + yyyy;
        currentDatesplit = today1.split("/", 3);
        console.log(currentDatesplit);
        //console.log(this.patient.apt)

        
        for (var val of this.patient.apt) {
            console.log(val.did);
            console.log(this.ss.$key);
            if (val.did == this.ss.$key) {
                console.log(this.ss.name);
                splitted = val.date.split("/", 3);
                console.log(splitted);
                if (Number(splitted[2]) < Number(currentDatesplit[2])) {
                    console.log('old appt year');
                    
                    aptFLAG = 1;
                }
                else {
                    if (Number(splitted[2]) == Number(currentDatesplit[2])) {
                        if (Number(splitted[1]) < Number(currentDatesplit[1])) {
                            console.log('same year old appt month')
                            aptFLAG = 1;

                        }
                        else {
                            if (Number(splitted[1]) == Number(currentDatesplit[1])) {
                                if (Number(splitted[0]) < Number(currentDatesplit[0])) {
                                    console.log('Same month old appt date');
                                    aptFLAG = 1;

                                } else {
                                    aptFLAG = 0;
                                }
                            }
                            else {
                                aptFLAG = 0;
                            }
                        }
                    }
                    else {
                        aptFLAG = 0;
                    }
                }
            }
            else {
                cnt = cnt + 1;
            }
        }
        if (aptFLAG == 1 || (cnt == this.patient.apt.length)) {
            this.aptm.pid = this.pat1_key;
            this.aptm.pname = this.patient.name;
            this.aptm.contact = this.patient.contact;
            this.doctor.apt.push(this.aptm);
            this.doctorservice.updateDoctors(this.doctor, this.ss.$key);

            this.presentToast1();
        }
        else {
            this.presentToast2();
        }
    }

    
    aptInfo() {
        
        this.prbtosend.patient_id = this.pat1_key;
        this.prbtosend.patient_name = this.patient.name;
        this.prbtosend.patient_problem = this.aptForm.get('myOmy').value;
        this.doctor.prb.push(this.prbtosend);
        console.log(this.doctor);

        this.doctorservice.updateDoctors(this.doctor, this.ss.$key);
        //this.openform = false;
        this.presentToast();
        //console.log("Yess");
        this.openform = false;
    }

    async presentToast() {
        const toast = await this.toastController.create({
            position: 'bottom',
            color: 'primary',
            message: 'Problrm Sent Successfully.',
            duration: 2000
        });
        toast.present();
    }

    async presentToast1() {
        const toast1 = await this.toastController1.create({
            position: 'middle',
            color: 'primary',
            message: 'You will receive time shortly.',
            duration: 2000
        });
        toast1.present();
    }

    async presentToast2() {
        const toast2 = await this.toastController2.create({
            position: 'middle',
            color: 'primary',
            message: 'Appointment exists',
            duration: 2000
        });
        toast2.present();
    }

    whatsapp() {
        this.socialSharing.shareViaWhatsApp(this.patient.name).then(() => { }).catch(e => { alert(e)});
    }
    instagram() {
        this.socialSharing.shareViaInstagram(this.patient.name,null);
    }
    facebook() {
        this.socialSharing.shareViaFacebookWithPasteMessageHint(this.patient.name).then(() => { }).catch(e => { alert(e) });
    }

}
