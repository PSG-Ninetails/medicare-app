import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DoctormodalPage } from './doctormodal.page';

describe('DoctormodalPage', () => {
  let component: DoctormodalPage;
  let fixture: ComponentFixture<DoctormodalPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DoctormodalPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DoctormodalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
