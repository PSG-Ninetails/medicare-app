import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DoctormodalPage } from './doctormodal.page';

const routes: Routes = [
  {
    path: '',
    component: DoctormodalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DoctormodalPageRoutingModule {}
