import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SupplierlistPage } from './supplierlist.page';

describe('SupplierlistPage', () => {
  let component: SupplierlistPage;
  let fixture: ComponentFixture<SupplierlistPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupplierlistPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SupplierlistPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
