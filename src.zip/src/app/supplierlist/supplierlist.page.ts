import { Component, OnInit } from '@angular/core';
import { Supplier } from '../../shared/supplier_type';
import { SuppliermodalPage } from '../suppliermodal/suppliermodal.page';
import { ModalController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-supplierlist',
  templateUrl: './supplierlist.page.html',
  styleUrls: ['./supplierlist.page.scss'],
})
export class SupplierlistPage implements OnInit {

    

    suppliers: Supplier[] = [
        { id: 1, name: 'Pappu', store_name: 'Kar Dhamal', image: '../../assets/images/bang.png', description: 'Best Store in sangavi' },
        { id: 2, name: 'ShantaBai', store_name: 'Bhai chi Krupa', image: '../../assets/images/bb_test1.png', description: 'Shantabaichya Krupeni dhanda dabal' }
    ];
    constructor(public modalController: ModalController, private router: Router) { }

  ngOnInit() {
  }

    async presentModal(s: Supplier) {
        const modal = await this.modalController.create({
            component: SuppliermodalPage,
            componentProps: {
                ss: s
            }
            //cssClass: 'my-custom-class'
        });
        return await modal.present();
    }

    back() {
        this.router.navigateByUrl('/medical');
    }
    
}
