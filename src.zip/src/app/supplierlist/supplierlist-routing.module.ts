import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SupplierlistPage } from './supplierlist.page';

const routes: Routes = [
  {
    path: '',
    component: SupplierlistPage
    },
    {
        path: 'medical',
        loadChildren: () => import('../medical/medical.module').then(m => m.MedicalPageModule)
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SupplierlistPageRoutingModule {}
