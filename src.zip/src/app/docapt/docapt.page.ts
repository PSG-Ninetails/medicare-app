import { Component, OnInit,Input } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Doctor } from '../../shared/doctor_type';
import { DApt } from '../../shared/apt';
import { PatientService } from '../../providers/patient-service.service';
import { Patient } from '../../shared/patient_type';
import { DatePipe } from '@angular/common';
import { PApt } from '../../shared/papt';
import { ToastController } from '@ionic/angular';
import { DoctorService } from '../../providers/doctor-service.service';

@Component({
  selector: 'app-docapt',
  templateUrl: './docapt.page.html',
  styleUrls: ['./docapt.page.scss'],
})
export class DocaptPage implements OnInit {

    @Input() aptD_key: string;
    doo_fetched: Doctor = { $key: '', username: '', password: '', dtype: '', area: '', name: '', prb: [], apt: [], available: false };
    pat_fetch: Patient = { $key: '', username: '', password: '', name: '', contact: '', prescription: [], recentlyvisited: [], apt: [] };
    patients: Patient[];
    ishidden: Boolean;
    selectedP: DApt;
    appt: PApt = { did: '', dname: '', date: '', dtype: '', area:'' };

    constructor(private modalCtrl: ModalController, public patientservice: PatientService, public toastController: ToastController,
        private doctorservice: DoctorService) { }

    ngOnInit() {
        this.ishidden = true;

        this.doctorservice.getDoctor(this.aptD_key).valueChanges().subscribe(res => {   //fetchig received doctor from db to get updated one
            this.doo_fetched = res;
            console.log(this.doo_fetched);
        });

        let bookingRes = this.patientservice.getPatients();
        bookingRes.snapshotChanges().subscribe(res => {
            this.patients = [];
            res.forEach(item => {
                let a = item.payload.toJSON();
                a['$key'] = item.key;
                this.patients.push(a as Patient);
            })
        })
    }

    dismiss() {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalCtrl.dismiss({
            'dismissed': true
        });
    }

    openreply(aa: DApt) {
        this.ishidden = false;
        this.selectedP = aa;
        console.log(this.selectedP);
        this.patientservice.getPatient(this.selectedP.pid).valueChanges().subscribe(res => {
            this.pat_fetch = res;
            console.log(this.pat_fetch);
        });
    }

    aptDate: any;

    sendtopatient() {
        let formatedDate = new DatePipe('en-US').transform(this.aptDate, 'dd/MM/yyyy');
        console.log(formatedDate);
        this.appt.area = this.doo_fetched.area;
        this.appt.did = this.aptD_key;
        this.appt.dname = this.doo_fetched.name;
        this.appt.dtype = this.doo_fetched.dtype;
        this.appt.date = formatedDate;
        this.pat_fetch.apt.push(this.appt);
        this.patientservice.updatePatients(this.pat_fetch, this.selectedP.pid);
        this.presentToast();
        this.ishidden = true;
    }

    async presentToast() {
        const toast = await this.toastController.create({
            message: 'Appointment Confirmed.',
            position: 'middle',
            color: 'primary',
            duration: 2000
        });
        toast.present();
    }

}
