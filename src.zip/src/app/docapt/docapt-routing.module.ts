import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DocaptPage } from './docapt.page';

const routes: Routes = [
  {
    path: '',
    component: DocaptPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DocaptPageRoutingModule {}
