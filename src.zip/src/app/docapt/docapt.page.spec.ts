import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DocaptPage } from './docapt.page';

describe('DocaptPage', () => {
  let component: DocaptPage;
  let fixture: ComponentFixture<DocaptPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocaptPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DocaptPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
