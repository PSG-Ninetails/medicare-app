import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PataptPageRoutingModule } from './patapt-routing.module';

import { PataptPage } from './patapt.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PataptPageRoutingModule
  ],
  declarations: [PataptPage]
})
export class PataptPageModule {}
