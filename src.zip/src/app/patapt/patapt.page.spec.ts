import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PataptPage } from './patapt.page';

describe('PataptPage', () => {
  let component: PataptPage;
  let fixture: ComponentFixture<PataptPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PataptPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PataptPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
