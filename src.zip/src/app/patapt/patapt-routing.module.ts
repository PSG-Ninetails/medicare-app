import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PataptPage } from './patapt.page';

const routes: Routes = [
  {
    path: '',
    component: PataptPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PataptPageRoutingModule {}
