import { Component, OnInit, Input } from '@angular/core';
import { PApt } from '../../shared/papt';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-patapt',
  templateUrl: './patapt.page.html',
  styleUrls: ['./patapt.page.scss'],
})
export class PataptPage implements OnInit {

    @Input() aptm: PApt[];

    constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
  }

    dismiss() {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalCtrl.dismiss({
            'dismissed': true
        });
    }

}
