import { Component, OnInit, Input } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Supplier } from '../../shared/supplier_type';

@Component({
  selector: 'app-suppliermodal',
  templateUrl: './suppliermodal.page.html',
  styleUrls: ['./suppliermodal.page.scss'],
})
export class SuppliermodalPage implements OnInit {

    @Input() ss: Supplier;

    constructor(private modalCtrl: ModalController) { }

    ngOnInit() {
  }
    dismiss() {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalCtrl.dismiss({
            'dismissed': true
        });
    }
}
