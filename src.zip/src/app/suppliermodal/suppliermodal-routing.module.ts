import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SuppliermodalPage } from './suppliermodal.page';

const routes: Routes = [
  {
    path: '',
    component: SuppliermodalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SuppliermodalPageRoutingModule {}
