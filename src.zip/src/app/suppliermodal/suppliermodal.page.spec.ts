import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SuppliermodalPage } from './suppliermodal.page';

describe('SuppliermodalPage', () => {
  let component: SuppliermodalPage;
  let fixture: ComponentFixture<SuppliermodalPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuppliermodalPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SuppliermodalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
