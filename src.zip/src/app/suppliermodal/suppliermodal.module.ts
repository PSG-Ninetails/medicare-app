import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SuppliermodalPageRoutingModule } from './suppliermodal-routing.module';

import { SuppliermodalPage } from './suppliermodal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SuppliermodalPageRoutingModule
  ],
  declarations: [SuppliermodalPage]
})
export class SuppliermodalPageModule {}
