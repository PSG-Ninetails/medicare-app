import { Component, OnInit } from '@angular/core';
import { ActionSheetController } from '@ionic/angular';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { Doctor } from '../../shared/doctor_type';
import { DoctorService } from '../../providers/doctor-service.service';
import { ModalController } from '@ionic/angular';
import { DocaptPage } from '../docapt/docapt.page';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.page.html',
  styleUrls: ['./doctor.page.scss'],
})
export class DoctorPage implements OnInit {

    doctor: Doctor = { $key: '', username: '', password: '', dtype: '', area: '', name: '', prb: [], apt: [], available: false };
    doc_log: Doctor;

    constructor(public modalController: ModalController,public actionSheetController: ActionSheetController, private router: Router,
        private route: ActivatedRoute, public doctorservice: DoctorService, public toastController: ToastController) {
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.doc_log = this.router.getCurrentNavigation().extras.state.doc;
            }
            console.log(this.doc_log); //always print inside paranthesis else undefined
        });
    }

    segment: string;
    ngOnInit() {
        this.doctorservice.getDoctor(this.doc_log.$key).valueChanges().subscribe(res => {   //fetchig received doctor from db to get updated one
            this.doctor = res;
            console.log(this.doctor);
            if (this.doctor.available == true) {
                this.segment = 'available';
            }
            else {
                this.segment = 'not-available';
            }
        });
    }

    
    segmentChanged(ev: any) {
        console.log('Segment changed', ev);
        console.log(this.segment);
        if (this.segment == 'available') {
            this.doctor.available = true;
            this.doctorservice.updateDoctors(this.doctor, this.doc_log.$key);
        }
        else {
            this.doctor.available = false;
            this.doctorservice.updateDoctors(this.doctor, this.doc_log.$key);
        }
    }

    async presentActionSheet() {
        //console.log(this.doctor);
        const actionSheet = await this.actionSheetController.create({
            header: 'Options',
            cssClass: 'my-custom-class',
            buttons: [
            {
                text: 'Virtual Consult',
                //role: 'destructive',
                icon: 'mail',
                    handler: () => {
                        let navigationExtras: NavigationExtras = {
                            state: {
                                doc1_key: this.doc_log.$key
                            }
                        };
                        this.router.navigateByUrl('/doctoroptions', navigationExtras);
                        console.log('Supplier List Opeed');
                }
            }, {
                text: 'Appointments',
                icon: 'share',
                handler: () => {
                    console.log('Apt clicked');
                    this.docaptModal();
                }
            }, {
                text: 'Cancel',
                icon: 'close',
                role: 'cancel',
                handler: () => {
                    console.log('Cancel clicked');
                }
            }]
        });
        await actionSheet.present();
    }

    async docaptModal() {
        if (this.doctor.apt.length != 0) {
            const modal = await this.modalController.create({
                component: DocaptPage,
                componentProps: {
                    aptD_key: this.doc_log.$key
                }
                //cssClass: 'my-custom-class'
            });
            return await modal.present();
        }
        else {
            this.presentToast();
        }
    }

    async presentToast() {
        const toast = await this.toastController.create({
            position: 'bottom',
            color: 'danger',
            message: 'No Appointments to open.',
            duration: 2000
        });
        toast.present();
    }
}
