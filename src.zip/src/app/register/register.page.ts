import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Doctor } from '../../shared/doctor_type';
import { DoctorService } from '../../providers/doctor-service.service';
import { Patient } from '../../shared/patient_type';
import { PatientService } from '../../providers/patient-service.service';


@Component({
    selector: 'app-register',
    templateUrl: './register.page.html',
    styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

    isNotDoctor: Boolean;
    isNotPatient: Boolean;
    registerForm: FormGroup;
    newDoctorId: number;
    newPatientId: number;
    newDoctor: Doctor = { $key: '', username: '', password: '', dtype: '', area: '', name: '', prb: [], apt: [], available: false };
    doctors: Doctor[];
    newPatient: Patient = { $key: '', username: '', password: '', name: '', contact: '', prescription: [], recentlyvisited: [], apt: [] };
    patients: Patient[];

    constructor(private formBuilder: FormBuilder, private router: Router, public doctorservice: DoctorService,
        public patientservice: PatientService) {
        this.isNotDoctor = true;
        this.isNotPatient = true;
        this.registerForm = this.formBuilder.group({
            Category: [''],
            DocName: [''],
            DocType: [''],
            DocArea: [''],
            DocUsername: [''],
            DocPassword: [''],
            PatName: [''],
            PatContact: [''],
            PatUsername: [''],
            PatPassword:['']
        });
    }

    onBlur() {
        if (this.registerForm.get('Category').value == 'doctor') {
            this.isNotDoctor = false;
            this.isNotPatient = true;
        }
        else {
            if (this.registerForm.get('Category').value == 'patient') {
                this.isNotDoctor = true;
                this.isNotPatient = false;
            }
        }
    }

    ngOnInit() {
    }

    getId() {
        if (this.registerForm.get('Category').value == 'doctor') {
            /*this.doctorservice.getDoctors().subscribe(doctors => {
                this.doctors = doctors;
                this.newDoctorId = this.doctors.length + 1;
                this.newDoctor.id = this.newDoctorId;         //values we get from subscribe should be set in curly braces only.
            }); */
        }
        else {
            if (this.registerForm.get('Category').value == 'patient') {
                /*this.patientservice.getPatients().subscribe(patients => {
                    this.patients = patients;
                    this.newPatientId = this.patients.length + 1;
                    this.newPatient.id = this.newPatientId;
                }); */
            }
        }
    }

    createUser() {
       // this.getId();
        if (this.registerForm.get('Category').value == 'doctor') {
            //this.newDoctor.id = this.newId;         //id set in getID
            this.newDoctor.name = this.registerForm.get('DocName').value;
            this.newDoctor.dtype = this.registerForm.get('DocType').value;
            this.newDoctor.area = this.registerForm.get('DocArea').value;
            this.newDoctor.username = this.registerForm.get('DocUsername').value;
            this.newDoctor.password = this.registerForm.get('DocPassword').value;

            var a1 = { patient_id: 'help', patient_name: 'help', patient_problem: 'help' };   //temporary fix
            var a2 = {pid:'hell',pname:'hell',contact:'9'};        //fix
            this.newDoctor.apt.push(a2);    //fix
            this.newDoctor.prb.push(a1);    //fix
            //console.log(this.newDoctor);
            this.doctorservice.pushDoctors(this.newDoctor);
        }
        else {
            if (this.registerForm.get('Category').value == 'patient') {
                this.newPatient.name = this.registerForm.get('PatName').value;
                this.newPatient.contact = this.registerForm.get('PatContact').value;
                this.newPatient.username = this.registerForm.get('PatUsername').value;
                this.newPatient.password = this.registerForm.get('PatPassword').value;

                
                var a3 = {did:'help',dname:'help',dtype:'help',area:'help',date:'help'};
                var a4 = { id: 'h', dname: 'h', dtype: 'h', area: 'h', prb: 'h', aid: 'h' };
                var a5 = { dtype: 'h', dname: 'h', area: 'h',did:'' };
                this.newPatient.apt.push(a3);
                this.newPatient.prescription.push(a4);
                this.newPatient.recentlyvisited.push(a5);
                this.patientservice.pushPatients(this.newPatient);
            }
        }
        this.router.navigateByUrl('/login');
    }
}
