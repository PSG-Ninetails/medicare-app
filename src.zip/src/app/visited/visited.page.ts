import { Component, OnInit, Input } from '@angular/core';
import { Patient } from '../../shared/patient_type';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-visited',
  templateUrl: './visited.page.html',
  styleUrls: ['./visited.page.scss'],
})
export class VisitedPage implements OnInit {

    @Input() recent: Patient;

    constructor(private modalCtrl: ModalController) { }

    ngOnInit() {
  }

    dismiss() {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalCtrl.dismiss({
            'dismissed': true
        });
    }

}
