import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { VisitedPage } from './visited.page';

describe('VisitedPage', () => {
  let component: VisitedPage;
  let fixture: ComponentFixture<VisitedPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VisitedPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(VisitedPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
