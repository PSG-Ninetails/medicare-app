import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VisitedPageRoutingModule } from './visited-routing.module';

import { VisitedPage } from './visited.page';

@NgModule({
  imports: [
        CommonModule,
        BrowserModule,
    FormsModule,
    IonicModule,
    VisitedPageRoutingModule
  ],
  declarations: [VisitedPage]
})
export class VisitedPageModule {}
