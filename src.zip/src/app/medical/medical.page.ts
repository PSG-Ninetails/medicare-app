import { Component, OnInit } from '@angular/core';
import { ActionSheetController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-medical',
  templateUrl: './medical.page.html',
  styleUrls: ['./medical.page.scss'],
})
export class MedicalPage implements OnInit {

    constructor(public actionSheetController: ActionSheetController, private router: Router) { }

  ngOnInit() {
  }

    async presentActionSheet() {
        const actionSheet = await this.actionSheetController.create({
            header: 'Options',
            cssClass: 'my-custom-class',
            buttons: [{
                text: 'Supplier List',
                //role: 'destructive',
                icon: 'mail',
                handler: () => {
                    this.gotoSupplierList();
                    console.log('Supplier List Opeed');
                }
            }, {
                text: 'Supplier Order Status',
                icon: 'share',
                handler: () => {
                    console.log('Share clicked');
                }
            }, {
                text: 'Regular Customer list',
                icon: 'caret-forward-circle',
                handler: () => {
                    console.log('Customer list ope');
                }
            }, {
                text: 'Favorite',
                icon: 'heart',
                handler: () => {
                    console.log('Favorite clicked');
                }
            }, {
                text: 'Cancel',
                icon: 'close',
                role: 'cancel',
                handler: () => {
                    console.log('Cancel clicked');
                }
            }]
        });
        await actionSheet.present();
    }

    gotoSupplierList() {
        this.router.navigateByUrl('/supplierlist');
    }

    segmentChanged(ev: any) {
        console.log('Segment changed', ev);
    }
    

}
