import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MedicalPage } from './medical.page';

const routes: Routes = [
  {
    path: '',
    component: MedicalPage
    },
    {
        path: 'supplierlist',
        loadChildren: () => import('../supplierlist/supplierlist.module').then(m => m.SupplierlistPageModule)
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MedicalPageRoutingModule {}
